###DRAFT DRAFT####


# analyzeSpaces<-function(
#   
# ){
#  
#   #stuff inside here to do things
#    
# }